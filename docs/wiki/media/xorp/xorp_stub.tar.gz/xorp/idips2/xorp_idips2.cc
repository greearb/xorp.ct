
//
// XORP Idips2 module implementation.
//

#include "idips2_module.h"

#include "libxorp/xorp.h"
#include "libxorp/xlog.h"
#include "libxorp/debug.h"
#include "libxorp/callback.hh"
#include "libxorp/eventloop.hh"
#include "libxorp/exceptions.hh"

#include "xrl_idips2_node.hh"

#ifdef HAVE_GETOPT_H
#include <getopt.h>
#endif

//
// Local functions prototypes
//

static void
idips2_main(const string& finder_hostname, uint16_t finder_port)
{
    //
    // Init stuff
    //
    EventLoop eventloop;

    //
    // Idips2 node
    //
    XrlIdips2Node xrl_idips2_node(
	eventloop,
	"idips2",
	finder_hostname,
	finder_port,
	"finder",
	"fea",
	"rib");
    wait_until_xrl_router_is_ready(eventloop,
				   xrl_idips2_node.xrl_router());

    // Startup
    xrl_idips2_node.startup();

    //
    // Main loop
    //
    while (! xrl_idips2_node.is_done()) {
	eventloop.run();
    }
}

int
main(int argc, char *argv[])
{
	argc = argc;
    //int ch;
    //string::size_type idx;
    //const char *argv0 = argv[0];
    string finder_hostname = FinderConstants::FINDER_DEFAULT_HOST().str();
    uint16_t finder_port = FinderConstants::FINDER_DEFAULT_PORT();

    //
    // Initialize and start xlog
    //
    xlog_init(argv[0], NULL);
    xlog_set_verbose(XLOG_VERBOSE_LOW);		// Least verbose messages
    // XXX: verbosity of the error messages temporary increased
    xlog_level_set_verbose(XLOG_LEVEL_ERROR, XLOG_VERBOSE_HIGH);
    xlog_add_default_output();
    xlog_start();

	printf("started\n");
    //
    // Run everything
    //
    try {
	idips2_main(finder_hostname, finder_port);
    } catch(...) {
	xorp_catch_standard_exceptions();
    }

    //
    // Gracefully stop and exit xlog
    //
    xlog_stop();
    xlog_exit();

    exit (0);
}
