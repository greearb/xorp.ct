/*
 * Module definitions.
 */
#ifndef __IDIPS_IDIPS_MODULE_H__
#define __IDIPS_IDIPS_MODULE_H__

#ifndef	XORP_MODULE_NAME
#define XORP_MODULE_NAME	"IDIPS"
#endif
#ifndef XORP_MODULE_VERSION
#define XORP_MODULE_VERSION	"0.1"
#endif

#endif /* __IDIPS_IDIPS_MODULE_H__ */
